#include <iostream>
#include <cstring>
#include <stdio.h>
#include <stdlib.h>

using namespace std;

int main()
{
    int n,m,v[256],x,a[256];
    char p[5];
    scanf("%s",p);

    n=atoi(p);
    if(n==0)
        scanf("%d",&n);
    scanf("%d",&m);

    for(int i=0; i<n*m; i++)
        scanf("%d",&v[i]);

    scanf("%s",p); //let
    scanf("%s",p); //x
    scanf("%s",p);
x=atoi(p);
      if(x!=0)
{
        scanf("%s",p);
        if(p[0]=='a')
            for(int i=0; i<n*m; i++)
                v[i]+=x;
        if(p[0]=='s')
            for(int i=0; i<n*m; i++)
                v[i]-=x;
        if(p[0]=='m')
            for(int i=0; i<n*m; i++)
                v[i]*=x;
        if(p[0]=='d')
            for(int i=0; i<n*m; i++)
                v[i]/=x;
    cout<<n<<" "<<m<<" ";
    for(int i=0;i<n*m;i++)
        cout<<v[i]<<" ";
    }
    else if(x==0)
    {
        for(int i=0;i<n;i++)
            for(int j=0;j<m;j++)
              a[j*n+n-i-1]=v[i*m+j];
    cout<<m<<" "<<n<<" ";
    for(int i=0;i<n*m;i++)
        cout<<a[i]<<" ";
    }

    return 0;
}

