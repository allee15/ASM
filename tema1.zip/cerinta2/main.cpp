#include <iostream>
#include <cstring>
#include <stdlib.h>

using namespace std;

struct nod
{
    int info;
    nod*adr;
};
void push(nod *&vf, int x)
{
    nod*p=new nod;
    p->info=x;
    p->adr=vf;
    vf=p;
}

int pop(nod *&vf, int &x)
{
    if(vf==NULL)
        return 0;
    else {
        x= vf->info;
        nod*p=vf;
        vf=vf->adr;
        delete p;
        return 1;}
}

int main()
{
    char s[256], *p;
    cin.get(s,256);
    int x=0,a,b;
    nod*vf=NULL;
    p= strtok(s," ");
    while(p)
    {
        x= atoi(p);
        if(x==0)
        {
            if(p[0]=='a')
            {
                pop(vf,a);
                pop(vf,b);
                push(vf,a+b);
            }
            if(p[0]=='s')
            {
              pop(vf,a);
              pop(vf,b);
              push(vf,b-a);
            }
            if(p[0]=='m')
            {
              pop(vf,a);
              pop(vf,b);
              push(vf,a*b);
            }
            if(p[0]=='d')
            {
                pop(vf,a);
                pop(vf,b);
                push(vf, b/a);
            }
        }
        else
            push(vf,x);
    p=strtok(NULL," ");
    }
    cout<<vf->info;
    return 0;
}


