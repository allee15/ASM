#include <iostream>
#include <cstring>

using namespace std;

int main()
{
    char s[256];
    int a[512], l=0;
    cin.get(s,256);
    for(int i=0; i<strlen(s); i++)
    {
        if(s[i]>= 'A' && s[i]<='F')
        {
            int x= s[i]+ 10- 'A';
            a[l++]= x;
        }
        else if(s[i]>='0' && s[i]<='9')
        {
            int x= s[i] - '0';
            a[l++]= x;
        }
    }
    for(int i=0; i<l; i=i+3)
    {
        int type=a[i]/2%4;
        int sgn = a[i]%2;
        int val = a[i+1]*16 + a[i+2];

        if( type==0)
        {
            if(sgn==0)
                cout<<val<<" ";
            else
                cout<<-val<<" ";
        }

        if (type==1)
            cout<<(char)val<<" ";

        if (type==2)
            {
                if (val==0) cout<<"let"<<" ";
                if (val==1) cout<<"add"<<" ";
                if (val==2) cout<<"sub"<<" ";
                if (val==3) cout<<"mul"<<" ";
                if (val==4) cout<<"div"<<" ";
            }

    }
    return 0;
}
