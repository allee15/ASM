#include <stdio.h>
#include <stdlib.h>

int v[90],p[30],f[30],n,m;

void back(int k)
{
    if(k<3*n)
    {
        if(v[k]==0)
        {
            for(int i=1; i<=n; i++)
            {
                if(p[i]+m<k&&f[i]<3)
                {
                    int pos = p[i];
                    v[k]=i;
                    p[i]=k;
                    f[i]++;
                    back(k+1);
                    f[i]--;
                    p[i]=pos;
                }
            }
            v[k]=0;
        }
        else
        {
            int pos = p[v[k]];
            if(pos+m>=k||f[v[k]]>=3)
                return;
            p[v[k]] = k;
            f[v[k]]++;
            back(k+1);
            f[v[k]]--;
            p[v[k]] = pos;
        }


    }
    else
    {
        for(int i=0; i<3*n; i++)
        {
            printf("%d ",v[i]);
        }
        printf("\n");
        exit(0);
    }
}

int main()
{
    scanf("%d %d",&n,&m);
    for(int i=0; i<3*n; i++)
    {
        scanf("%d",&v[i]);
        p[i]=-90;
    }
    back(0);
    printf("-1\n");
    return 0;
}
